<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'tato_studio_db' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'nlMs#<:i04{ALh/6vb;P`WmQm[)99/%>0g1W4zp*TOeI]7; ]JR<4H%I_T}tD6T*' );
define( 'SECURE_AUTH_KEY',  '0*t2%wlP:c,/!>FV^v4{[1PILd~yBPkpij%-HaBTJcI&RK)9;|znR=n3IHE*]z:F' );
define( 'LOGGED_IN_KEY',    '`Y8C=G{Wt4b1h6b{aZl,ob&>a4Q_%C!mgtZ:Dv3o;r^ZLNCn/CA^fsD>sNoPgbpx' );
define( 'NONCE_KEY',        'rmd.apAH,%DTKg:2H|TqK>FH$|0r71p=e2bT!=CZw@_|^GvUTOz:u])Y}}OI+Hl3' );
define( 'AUTH_SALT',        'EpO!|#{g-<[06*}$g({59|uwxZgf_WE7lzBJkY~Uf?.E!8)ZS?Hc3T2 +x,)r~y%' );
define( 'SECURE_AUTH_SALT', '<<C4o}g{bA]vq9)AFN]2NyqVYHE7[-H2-iC1@.}^NV.U|o0;psPq1ovhH7}giWpI' );
define( 'LOGGED_IN_SALT',   ']*4^wct%C+3&tfq-^{MQbPOnr$OgZJgW,jXUN%Ke}gK<zR3`/8/xV70]AuYNt>sF' );
define( 'NONCE_SALT',       'x.7]n}#reMEqrF+tcu9}2|,9!y0kyHL0ut4deQ%xkgRj6?yO!}p/<rj}~?XnnmU[' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
